the compile line we were using was

g++ -std=c++11 chrono.cpp hades.cpp BrokerageMain.cpp -o main
