
the compile line we were using was

g++ BrokerageMain.cpp Brokerage.cpp Chrono.cpp -std=c++11 -o BrokerageMain
